# ContestParticipationSystem

A simple ASP.NET Core Web API for managing contest participation with JWT authentication, rate limiting, and role-based middleware.

## Features
- User authentication with JWT (HS256)
- Role-based access control
- Rate limiting middleware
- Exception handling middleware
- EF Core (SQL Server) for persistence
- Swagger UI for API exploration

## Prerequisites
- .NET 8 SDK
- SQL Server (or SQL Server Express)
- An editor or IDE (Visual Studio 2022, VS Code, etc.)

## Configuration
Configuration is read from `appsettings.json` (or environment variables). Important keys:	

- `ConnectionStrings:Default` � SQL Server connection string.
- `Jwt:Key` � Signing key for JWTs. MUST be at least 32 bytes (256 bits) when decoded (see below).
- `Jwt:Issuer`, `Jwt:Audience` � optional.

Example `appsettings.json` snippet:

```
"Jwt": {
  "Key": "REPLACE_WITH_STRONG_BASE64_KEY_OR_AT_LEAST_32_CHAR_STRING",
  "Issuer": "ContestAPI",
  "Audience": "ContestUsers"
}
```

Important: the framework enforces a minimum HMAC key length for HS256. If you see `IDX10720: ... key size must be greater than: '256' bits ...` your configured key is too short (for example `SuperSecretKey123456789` is 23 bytes). Use a Base64-encoded 32+ byte key or a UTF-8 string of at least 32 characters.

### Generate a secure Base64 32-byte key
- PowerShell:
```
$bytes = New-Object byte[] 32; (New-Object System.Security.Cryptography.RNGCryptoServiceProvider).GetBytes($bytes); [Convert]::ToBase64String($bytes)
```
- OpenSSL:
```
openssl rand -base64 32
```

## Running locally
1. Update `appsettings.json` or set environment variables for the DB and a secure `Jwt:Key`.
2. From the solution folder:
```
dotnet restore
# if migrations exist
dotnet ef database update
dotnet run
```
3. Open Swagger at `https://localhost:<port>/swagger`.

## Database
The project uses EF Core with SQL Server. Add migrations and update the DB if needed:
```
dotnet ef migrations add InitialCreate
dotnet ef database update
```

## Security notes
- Store secrets (JWT keys, DB passwords) in a secure store, environment variables, or user-secrets � do not commit them to source control.
- Prefer Base64-encoded byte keys for clarity about length.
- Consider rotating keys or using asymmetric signing (RS256) for stronger security.

## Troubleshooting
- IDX10720 on token generation: JWT signing key length is insufficient. Ensure `Jwt:Key` decodes to at least 32 bytes.
- "Invalid signature" on validation: ensure same key/encoding is used by issuer and validator.

## Contributing
Fork, open issues, or submit pull requests.

---
Generated for the ContestParticipationSystem project. Update secrets and DB connection before running.
